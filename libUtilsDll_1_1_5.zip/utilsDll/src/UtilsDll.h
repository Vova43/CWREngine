/*
 ============================================================================
 Name        : UtilsDll.h
 Author      : Vova43
 Version     : 1.1.5
 Copyright   : MIT License
 Description : FileWrapper in C, Ansi-style
 ============================================================================
 */
#ifndef UtilsDllx86_H_
#define UtilsDllx86_H_

#ifdef UtilsDllx86_EXPORTS
    #define UtilsDllx86_API __declspec(dllexport)
#else
    #define UtilsDllx86_API __declspec(dllimport)
#endif

#define CALL __cdecl
//#define CALL __stdcall // <<-- -Wl,--kill-at
int main(void);
typedef struct {
    FILE *file;
} FileWrapper;
UtilsDllx86_API FileWrapper* CALL fopen_wrapper(const char *filename, const char *mode);
UtilsDllx86_API size_t CALL fread_wrapper(void *ptr, size_t size, size_t count, FileWrapper *fw);
UtilsDllx86_API size_t CALL fwrite_wrapper(const void *ptr, size_t size, size_t count, FileWrapper *fw);
UtilsDllx86_API char* CALL fgets_wrapper(char *str, int num, FileWrapper *fw);
UtilsDllx86_API int CALL fprintf_wrapper(FileWrapper *fw, const char *format, ...);
UtilsDllx86_API long CALL ftell_wrapper(FileWrapper *fw);
UtilsDllx86_API int CALL fseek_wrapper(FileWrapper *fw, long offset, int whence);
UtilsDllx86_API int CALL feof_wrapper(FileWrapper *fw);
UtilsDllx86_API int CALL fflush_wrapper(FileWrapper *fw);
UtilsDllx86_API long CALL get_file_size_wrapper(FileWrapper *fw);
UtilsDllx86_API int CALL ferror_wrapper(FileWrapper *fw);
UtilsDllx86_API int CALL remove_wrapper(const char *filename);
UtilsDllx86_API int CALL copy_file(const char *source, const char *destination);
UtilsDllx86_API int CALL fclose_wrapper(FileWrapper *fw);
UtilsDllx86_API HINSTANCE CALL getHINSTANCE();
UtilsDllx86_API LPCSTR CALL getVersion();

typedef struct _ImageRec {
	unsigned short imagic;
	unsigned short type;
	unsigned short dim;
	unsigned short xsize, ysize, zsize;
	unsigned int min, max;
	unsigned int wasteBytes;
	char name[80];
	unsigned long colorMap;
	FILE *file;
	unsigned char *tmp, *tmpR, *tmpG, *tmpB;
	unsigned long rleEnd;
	unsigned int *rowStart;
	int *rowSize;
} ImageRec;

UtilsDllx86_API unsigned * CALL nativeReadImageRLE(const char *filename, int *width, int *height, int *depth);
UtilsDllx86_API void * CALL nativeReadImage(const char *filename, int *width, int *height, int *depth, int req_comp);

#endif // UtilsDllx86_H_s
